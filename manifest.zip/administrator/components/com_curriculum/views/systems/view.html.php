<?php
/**
 * Created by PhpStorm.
 * User: Curtis
 * Date: 12/21/2014
 * Time: 6:39 PM
 */
defined('_JEXEC') or die("Access Denied");
jimport('joomla.application.component.view');

class CurriculumViewSystems extends JView
{

}