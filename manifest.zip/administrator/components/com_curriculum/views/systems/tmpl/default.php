<?php
/**
 * Created by PhpStorm.
 * User: Curtis
 * Date: 12/21/2014
 * Time: 6:45 PM
 */
defined('_JEXEC') or die("Access Denied");